"""Generate an isolated DEV runner that publishes actual authorization messages."""
import ast
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
PROJECT = BASE.parent
PREFIX = BASE.name


def once(text, old, new):
    assert text.count(old) == 1, old[:80]
    return text.replace(old, new)


def main():
    text = (PROJECT / 'scene_runner_mechpairs_v1.py').read_text()
    assert hashlib.sha256(text.encode()).hexdigest() == '4589b8b77171738e7c7e6de2900de52f88636d6eca020257274e307cf397c072'
    text = once(text, 'from rulesync_interfaces.msg import RuleGuardState',
                '''from rulesync_interfaces.msg import RuleGuardState, ExecutionAuthorization
from nav_msgs.msg import Path as NavPath
from rosidl_runtime_py.convert import message_to_ordereddict
from probe_logic import make_probe''')
    text = once(text, '    hashes=bench.freeze(root)', '''    hashes=bench.freeze(root)
    for extra in [Path(__file__),Path(__file__).with_name('probe_logic.py')]:
        index=len(hashes)
        hashes[str(extra)]=hashlib.sha256(extra.read_bytes()).hexdigest()
        shutil.copy2(extra,root/'source'/f'{index:02d}_{extra.name}')''')
    text = once(text, '        node.task_probes=probes', '''        node.auth_probe_inbox=[]; node.auth_probe_guard=[]; node.auth_probe_forwards=[]
        def captured_authorization(message):
            node.auth_probe_inbox.append(copy.deepcopy(message))
            with (root/'authorization_messages.jsonl').open('a') as stream:
                stream.write(json.dumps(dict(receipt_ns=time.monotonic_ns(),message=message_to_ordereddict(message)))+'\\n')
        def captured_guard(message):
            node.auth_probe_guard.append(dict(receipt_ns=time.monotonic_ns(),state=int(message.state),
                reason=str(message.reason),authority_epoch=int(message.authority_epoch),
                execution_epoch=int(message.execution_epoch)))
        def captured_forward(message):
            node.auth_probe_forwards.append(dict(receipt_ns=time.monotonic_ns(),points=len(message.poses)))
        node.auth_probe_sub=node.create_subscription(ExecutionAuthorization,'/rulesync/execution_authorization',captured_authorization,10)
        node.auth_probe_state_sub=node.create_subscription(RuleGuardState,'/rulesync/ruleguard_state',captured_guard,10)
        node.auth_probe_exec_sub=node.create_subscription(NavPath,'/rulepatch/executable_path',captured_forward,10)
        node.auth_probe_pub=node.create_publisher(ExecutionAuthorization,'/rulesync/execution_authorization',10)
        node.task_probes=probes''')
    text = once(text, '        bench.admit(node,path,1); node.active=True', '''        bench.admit(node,path,1)
        base.wait(node,lambda:any(a.epoch==1 for a in node.auth_probe_inbox),5.)
        historical_authorization=copy.deepcopy(next(a for a in reversed(node.auth_probe_inbox) if a.epoch==1))
        node.active=True''')
    start = text.index("        if MECH_MODE=='out_of_order':", text.index("result['phase']='recovery_follow'"))
    end = text.index('        final=bench.follow(node,path,2)', start)
    text = text[:start] + '''        if MECH_MODE=='out_of_order':
            base.wait(node,lambda:any(a.epoch==2 for a in node.auth_probe_inbox),5.)
            fresh_authorization=copy.deepcopy(next(a for a in reversed(node.auth_probe_inbox) if a.epoch==2))
            kind=os.environ['RULESYNC_AUTH_PROBE_KIND']
            injected=make_probe(fresh_authorization,historical_authorization,kind)
            assert node.guard.authority_epoch==2 and node.guard.execution_epoch==2
            assert node.guard.state!=RuleGuardState.HOLD, 'positive control not CLEAR/WARNING'
            base.wait(node,lambda:node.auth_probe_pub.get_subscription_count()>=1,5.)
            write(root/'injected_authorization.json',message_to_ordereddict(injected))
            sent=time.monotonic_ns()
            node.event('actual_authorization_probe_sent',probe_kind=kind,epoch=int(injected.epoch),
                snapshot_hash=injected.snapshot_hash,path_digest=injected.path_digest,token_id=injected.token_id,
                authority_epoch=int(node.guard.authority_epoch),positive_control_epoch=int(fresh_authorization.epoch))
            node.auth_probe_pub.publish(injected)
            base.wait(node,lambda:any(g['receipt_ns']>=sent and g['reason']=='authorization-identity-mismatch'
                and g['authority_epoch']==2 for g in node.auth_probe_guard),5.)
            bench.spin_for(node,.5)
            states=[g for g in node.auth_probe_guard if g['receipt_ns']>=sent]
            forwards=[f for f in node.auth_probe_forwards if f['receipt_ns']>=sent]
            assert any(g['reason']=='authorization-identity-mismatch' for g in states)
            assert not any(f['points']>0 for f in forwards), 'probe caused executable path release'
            witness=dict(probe_kind=kind,content_valid=True,positive_control_epoch=2,injected_epoch=int(injected.epoch),
                rejection_reason='authorization-identity-mismatch',guard_states=states,forwarded_paths=forwards,
                observation_window_s=.5,synthetic_identity=(kind=='stale_identity'),
                historical_envelope_replayed=(kind=='late_authorization'))
            write(root/'authorization_probe_witness.json',witness)
            result['authorization_probe']=witness
            node.event('actual_authorization_probe_rejected',**witness)
            # Fresh gate admission is required again after the stale envelope.
            bench.admit(node,path,2)
''' + text[end:]
    ast.parse(text)
    runner = BASE / 'scene_runner_authorization_probe.py'
    runner.write_text(text)
    runner_sha = hashlib.sha256(runner.read_bytes()).hexdigest()
    launcher = (PROJECT / 'run_mechpair_attempt.py').read_text()
    launcher = once(launcher, 'import run_native_furnished_recovery_dev_v2 as base',
                    'import sys\nsys.path.insert(0,str(Path(__file__).resolve().parent.parent))\nimport run_native_furnished_recovery_dev_v2 as base')
    launcher = launcher.replace('scene_runner_mechpairs_v1.py', PREFIX + '/scene_runner_authorization_probe.py')
    launcher = once(launcher, 'sys.path.insert(0, \'/experiment\')',
                    f"sys.path.insert(0, '/experiment/{PREFIX}')\nsys.path.insert(1, '/experiment')")
    launcher = once(launcher, 'MECHP_RUNNER_SHA = "4589b8b77171738e7c7e6de2900de52f88636d6eca020257274e307cf397c072"',
                    f'MECHP_RUNNER_SHA = "{runner_sha}"')
    launcher = once(launcher, '    root = base.ROOT', '''    root = base.ROOT
    pin = Path(__file__).resolve().parent/'source_pin.json'
    assert base.sha(pin)==opt.source_pin_sha, 'probe pin hash mismatch'
    for name,digest in json.loads(pin.read_text())['files'].items():
        assert base.sha(pin.parent/name)==digest, name
    names=subprocess.check_output(['podman','ps','--format','{{.Names}}'],text=True).splitlines()
    assert not any(n.startswith('rulesync-') for n in names), 'another RuleSync run is active'
    assert opt.tag.startswith('authprobe_'), 'new DEV tag required'
    assert opt.mech_mode=='out_of_order' and opt.monitor_arm=='full', 'qualification is full arm only'
    assert base.sha(root/MANIFEST)=='bb749f5d886ef5a0009966ce4d180b3c58e2c1d503213a918cedd94534dfef20'
    mem={ln.split(':')[0]:int(ln.split()[1]) for ln in Path('/proc/meminfo').read_text().splitlines()}
    assert mem['MemAvailable']>=7*1024*1024, 'less than 7GiB available' ''')
    launcher = once(launcher, '    # Remove any stale container/storage entry left by a crashed prior attempt.\n    subprocess.run(["podman", "rm", "-f", name], capture_output=True)',
                    '    name=name+"-authprobe"\n    assert name not in names')
    launcher = once(launcher, '    assert (root / case).is_file(), f"case missing: {case}"',
                    '''    assert (root / case).is_file(), f"case missing: {case}"
    assert base.sha(root/case)==m['cases'][opt.case_id]['sha256'], 'case differs from frozen input'
    for relative,digest in m['scenes'][opt.scene]['files_sha256'].items():
        assert base.sha(root/relative)==digest, relative
    migration=json.loads((root/scene/'migration_manifest.json').read_text())
    for relative,digest in migration['asset_files_sha256'].items():
        assert base.sha(root/asset_root/relative)==digest, relative''')
    launcher = once(launcher, 'f"RULESYNC_DYNAMIC_ARM={opt.monitor_arm}"]',
                    'f"RULESYNC_DYNAMIC_ARM={opt.monitor_arm}",\n                        "--env",f"RULESYNC_AUTH_PROBE_KIND={opt.probe_kind}"]')
    launcher = once(launcher, '    options = parser.parse_args()', '''    parser.add_argument('--probe-kind',choices=['stale_identity','late_authorization'],required=True)
    parser.add_argument('--source-pin-sha',required=True)
    options = parser.parse_args()''')
    ast.parse(launcher)
    (BASE / 'run_authorization_probe.py').write_text(launcher)
    files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in BASE.glob('*.py')}
    pin = dict(files=files, scope='DEV actual ExecutionAuthorization injection, not a new formal matrix',
               original_runner_sha256='4589b8b77171738e7c7e6de2900de52f88636d6eca020257274e307cf397c072')
    (BASE/'source_pin.json').write_text(json.dumps(pin,indent=2)+'\n')
    print('SOURCE_PIN',hashlib.sha256((BASE/'source_pin.json').read_bytes()).hexdigest())


if __name__ == '__main__':
    main()

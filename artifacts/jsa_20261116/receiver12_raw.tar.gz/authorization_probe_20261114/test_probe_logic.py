from pathlib import Path
import sys
from types import SimpleNamespace as N
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'rulesync3d'))
from rulesync3d.authorization import path_digest, token_id, verify_authorization
from probe_logic import make_probe


def envelope(epoch, x):
    header=N(frame_id='map',stamp=N(sec=10,nanosec=0))
    path=N(header=header,poses=[N(header=header,pose=N(position=N(x=x,y=0,z=0),orientation=N(x=0,y=0,z=0,w=1)))])
    digest=path_digest(path)
    return N(epoch=epoch,snapshot_hash=str(epoch)*64,path=path,path_digest=digest,
             token_id=token_id(epoch,str(epoch)*64,digest))


class ProbeTests(unittest.TestCase):
    def test_stale_identity_keeps_positive_control_path(self):
        old,fresh=envelope(1,0),envelope(2,2)
        probe=make_probe(fresh,old,'stale_identity')
        self.assertEqual(probe.path_digest,fresh.path_digest)
        self.assertEqual((probe.epoch,probe.snapshot_hash),(old.epoch,old.snapshot_hash))
        self.assertTrue(verify_authorization(probe.path,probe.path_digest,probe.token_id,probe.epoch,probe.snapshot_hash)[0])
        self.assertEqual(fresh.epoch,2)

    def test_late_authorization_is_actual_historical_envelope(self):
        old,fresh=envelope(1,0),envelope(2,2)
        probe=make_probe(fresh,old,'late_authorization')
        self.assertEqual((probe.epoch,probe.path_digest,probe.token_id),(old.epoch,old.path_digest,old.token_id))
        self.assertNotEqual(probe.path_digest,fresh.path_digest)

    def test_corrupt_control_cannot_be_injected(self):
        old,fresh=envelope(1,0),envelope(2,2)
        fresh.token_id='corrupted'
        with self.assertRaisesRegex(ValueError,'invalid control'):
            make_probe(fresh,old,'stale_identity')

    def test_same_generation_is_not_stale(self):
        with self.assertRaisesRegex(ValueError,'older'):
            make_probe(envelope(2,2),envelope(2,0),'stale_identity')

    def test_unknown_kind_fails(self):
        with self.assertRaisesRegex(ValueError,'unknown'):
            make_probe(envelope(2,2),envelope(1,0),'old-path-only')


if __name__=='__main__':unittest.main()

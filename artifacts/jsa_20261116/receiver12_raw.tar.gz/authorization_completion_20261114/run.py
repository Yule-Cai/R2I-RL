"""One sequential, frozen 12-trial DEV completion campaign. No retries."""
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
EXPECTED='f307d791de05f6f82cf081e570834553376dacf70001170632b6e3a9a8fbf231'


def write(path,value):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value,indent=2)+'\n')
    tmp.replace(path)


def main():
    assert ROOT==Path('/home/gamer/Projects/rulesync-iotj-environments-20261028')
    lock=(BASE/'writer.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (BASE/'progress.json').exists(), 'existing campaign must be reviewed, not restarted'
    manifest=BASE/'manifest.json'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest()==EXPECTED
    m=json.loads(manifest.read_text())
    progress=dict(manifest_sha256=EXPECTED,total=12,closed=0,active=None,rows=[],status='running')
    for row in m['rows']:
        tag='authprobe_completion12_20261114_v1_'+row['probe_kind']
        command=[sys.executable,str(ROOT/'authorization_probe_20261114/run_authorization_probe.py'),
                 '--scene',row['scene'],'--case-id',row['case_id'],'--speed',str(row['speed']),
                 '--seed',str(row['seed']),'--ros-domain','230','--tag',tag,'--mech-mode','out_of_order',
                 '--monitor-arm','full','--probe-kind',row['probe_kind'],'--source-pin-sha',row['source_pin_sha256']]
        progress['active']=row['id'];write(BASE/'progress.json',progress)
        started=time.time()
        with (BASE/(row['id']+'.log')).open('x') as log:
            process=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        out=ROOT/'mechpairs_runs'/tag/'mech_out_of_order_full'/f"{row['case_id']}_s20_seed{row['seed']}"/'position_1'
        result=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else None
        record=dict(spec=row,command=command,started=started,finished=time.time(),exit_code=process.returncode,
                    output=str(out.relative_to(ROOT)),result=result,
                    log_sha256=hashlib.sha256((BASE/(row['id']+'.log')).read_bytes()).hexdigest())
        with (BASE/'ledger.jsonl').open('a') as stream:
            stream.write(json.dumps(record,sort_keys=True)+'\n');stream.flush()
        progress['rows'].append(record);progress['closed']+=1;progress['active']=None
        write(BASE/'progress.json',progress)
        print(json.dumps(dict(closed=progress['closed'],id=row['id'],result=(result or {}).get('result'),exit_code=process.returncode)),flush=True)
        assert hashlib.sha256(manifest.read_bytes()).hexdigest()==EXPECTED
    progress['status']='closed_pending_independent_review'
    write(BASE/'progress.json',progress)


if __name__=='__main__':main()
